// Scuderia Command v1.1 Strategy Engine
function getStrategyState(tyre='Medium',lap=12){
 const wear=Math.min(100,lap*3);
 const pit=wear>65?'BOX THIS LAP':wear>45?'Pit Window Open':'Stay Out';
 const next=tyre==='Soft'?'Medium':tyre==='Medium'?'Hard':'Medium';
 return {wear,pit,next,message: pit==='Stay Out'?'Maintain pace':'Prepare pit stop'};
}
window.getStrategyState=getStrategyState;
